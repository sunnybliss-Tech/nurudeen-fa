
/* main.js - simplified */
const NEWS = [
  { id: 1, title: "U-17 Team Wins Regional Tournament", date: "2025-10-15", body: "Our U-17 squad defeated Kaduna Youth 2-0 to claim the regional championship."},
  { id: 2, title: "New Coaching Staff Announced", date: "2025-10-10", body: "NURUDEEN FA ABUJA welcomes Coach Emmanuel Okafor as Head Coach of the Senior Team."}
];
const TEAMS = [
  { id: "u10", name: "U-10 Boys", coach: "Coach A", img: "images/team-u10.jpg" },
  { id: "u15", name: "U-15 Boys", coach: "Coach C", img: "images/team-u15.jpg" },
  { id: "senior", name: "Senior Team", coach: "Coach Emmanuel Okafor", img: "images/team-senior.jpg" }
];
const FIXTURES = [
  { date: "2025-10-21", opponent: "Abuja Warriors", location: "National Stadium, Abuja", time: "16:00", result: null },
  { date: "2025-10-07", opponent: "Lagos United", location: "National Stadium, Abuja", time: "14:00", result: "3 - 1" }
];
function el(s){return document.querySelector(s)}
function elAll(s){return Array.from(document.querySelectorAll(s))}
function fmtDate(d){return new Date(d+"T00:00:00").toLocaleDateString()}
function renderTeams(){const c=el("#teams-list");if(!c)return;c.innerHTML='';TEAMS.forEach(t=>{const a=document.createElement('article');a.className='team-card';a.innerHTML=`<img src="${t.img}" style="width:100%"><h3>${t.name}</h3><p><strong>Coach:</strong> ${t.coach}</p>`;c.appendChild(a)})}
function renderFixtures(){const t=el("#fixtures-tbody");if(!t)return;t.innerHTML='';FIXTURES.forEach(f=>{const tr=document.createElement('tr');tr.innerHTML=`<td>${fmtDate(f.date)}</td><td>${f.opponent}</td><td>${f.location}</td><td>${f.time||''}</td><td>${f.result||''}</td>`;t.appendChild(tr)})}
function renderNews(){const n=el("#news-list");if(!n)return;n.innerHTML='';NEWS.forEach(i=>{const art=document.createElement('article');art.className='news-item';art.innerHTML=`<h2>${i.title}</h2><small>${fmtDate(i.date)}</small><p>${i.body}</p>`;n.appendChild(art)})}
function initVideo(){const ph=el("#video-placeholder"); if(!ph) return; const src=ph.getAttribute('data-src'); const btn=document.createElement('button'); btn.textContent='Play Highlights'; btn.addEventListener('click',()=>{const v=document.createElement('img');v.width=640;v.src=src;ph.innerHTML='';ph.appendChild(v);}); ph.appendChild(btn)}
document.addEventListener('DOMContentLoaded',()=>{renderTeams();renderFixtures();renderNews();initVideo()});
